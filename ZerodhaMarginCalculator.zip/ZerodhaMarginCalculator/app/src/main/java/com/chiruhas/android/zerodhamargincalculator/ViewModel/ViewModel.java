package com.chiruhas.android.zerodhamargincalculator.ViewModel;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.support.annotation.NonNull;

import com.chiruhas.android.zerodhamargincalculator.Model.Equity.EquityModel;
import com.chiruhas.android.zerodhamargincalculator.ViewModel.Repo.Repository;

import java.util.List;

public class ViewModel extends AndroidViewModel {
    Repository r;
    LiveData<List<EquityModel>> list ;
    public ViewModel(@NonNull Application application) {
        super(application);
        r = new Repository();
        list = r.getEquity();
    }
    public LiveData<List<EquityModel>> fetchEquity()
    {
        return list;
    }
}
