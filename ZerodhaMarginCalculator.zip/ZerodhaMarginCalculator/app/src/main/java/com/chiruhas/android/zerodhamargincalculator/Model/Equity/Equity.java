package com.chiruhas.android.zerodhamargincalculator.Model.Equity;

public class Equity {
    private String tradingsymbol;
    private int mis_multiplier;
    private int cnc_multiplier;

    public String getTrading_symbol() {
        return tradingsymbol;
    }

    public void setTrading_symbol(String trading_symbol) {
        this.tradingsymbol = trading_symbol;
    }

    public int getMis_multiplier() {
        return mis_multiplier;
    }

    public void setMis_multiplier(int mis_multiplier) {
        this.mis_multiplier = mis_multiplier;
    }

    public Equity() {

    }

    public Equity(String trading_symbol, int mis_multiplier) {

        this.tradingsymbol = trading_symbol;
        this.mis_multiplier = mis_multiplier;
        this.cnc_multiplier = 1;
    }
}
