package com.chiruhas.android.zerodhamargincalculator.View;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.chiruhas.android.zerodhamargincalculator.R;

public class MainActivity extends AppCompatActivity {

    Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



    }

    public void click(View v){
        switch (v.getId())
        {
            case R.id.equity:
                startActivity(new Intent(MainActivity.this,EquityActivity.class));
                break;
            case R.id.commodity:
                //
                break;
            case R.id.futures:
                //
                break;
            case R.id.currency:
                //
                break;
        }
    }
}
