package com.chiruhas.android.zerodhamargincalculator.ViewModel.Repo;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.util.Log;

import com.chiruhas.android.zerodhamargincalculator.Model.Equity.EquityModel;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Repository {
    Retrofit retrofit;
    ZerodhaClient zerodhaClient;
    MutableLiveData<List<EquityModel>> equityModels;
    public Repository()
    {
         retrofit= new Retrofit.Builder().baseUrl("https://api.kite.trade/margins/").addConverterFactory(GsonConverterFactory.create()).build();
        zerodhaClient= retrofit.create(ZerodhaClient.class);
        equityModels=new MutableLiveData<>();
    }

    public LiveData<List<EquityModel>> getEquity()
    {
        Call<List<EquityModel>> call = zerodhaClient.getEquity();
        call.enqueue(new Callback<List<EquityModel>>() {
            @Override
            public void onResponse(Call<List<EquityModel>> call, Response<List<EquityModel>> response) {
                if(!response.isSuccessful())
                {
                    return;
                }
               equityModels.setValue(response.body());
            }

            @Override
            public void onFailure(Call<List<EquityModel>> call, Throwable t) {
                Log.d("Repository","Failure "+t.getLocalizedMessage());
            }
        });
        return equityModels;

    }
}
