package com.chiruhas.android.zerodhamargincalculator.View;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import com.chiruhas.android.zerodhamargincalculator.BroadcastReceivers.Connectivity;
import com.chiruhas.android.zerodhamargincalculator.CustomAdapters.RecyclerViewAdapter;
import com.chiruhas.android.zerodhamargincalculator.Model.Equity.Equity;
import com.chiruhas.android.zerodhamargincalculator.Model.Equity.EquityModel;
import com.chiruhas.android.zerodhamargincalculator.R;
import com.chiruhas.android.zerodhamargincalculator.ViewModel.ViewModel;

import java.util.List;

public class EquityActivity extends AppCompatActivity {
    ViewModel view;
    RecyclerView rv;
    RecyclerViewAdapter recyclerViewAdapter;
    private static final String TAG = "EquityActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_equity);
        rv = findViewById(R.id.rv);
        Log.d(TAG, "onCreate: sucessful");
        rv.setLayoutManager(new LinearLayoutManager(this));

        /**
         * Regestering broad cast receiver
         */

        Connectivity connectivity = new Connectivity();
        IntentFilter intentFilter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(connectivity,intentFilter);

        recyclerViewAdapter = new RecyclerViewAdapter(new RecyclerViewAdapter.ItemListener() {
            @Override
            public void onItemClick(EquityModel item) {
                //popup
            }
        });
        rv.setAdapter(recyclerViewAdapter);
        view = ViewModelProviders.of(this).get(ViewModel.class);
        view.fetchEquity().observe(this, new Observer<List<EquityModel>>() {
            @Override
            public void onChanged(@Nullable List<EquityModel> equityModels) {
                recyclerViewAdapter.updateData(equityModels);
            }
        });


    }
}
