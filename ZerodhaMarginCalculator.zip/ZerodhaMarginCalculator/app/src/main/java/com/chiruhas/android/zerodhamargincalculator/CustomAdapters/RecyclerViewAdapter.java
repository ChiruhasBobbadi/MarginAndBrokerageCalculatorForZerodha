
package com.chiruhas.android.zerodhamargincalculator.CustomAdapters;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.chiruhas.android.zerodhamargincalculator.Model.Equity.Equity;
import com.chiruhas.android.zerodhamargincalculator.Model.Equity.EquityModel;
import com.chiruhas.android.zerodhamargincalculator.R;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {

    private List<EquityModel> myItems = new ArrayList<>();
    private ItemListener myListener;

    public RecyclerViewAdapter( ItemListener listener) {

        myListener = listener;
    }

    public void setListener(ItemListener listener) {
        myListener = listener;
    }

    public void updateData(List<EquityModel> equityModels)
    {
        myItems= equityModels;
        notifyDataSetChanged();
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext())
                .inflate(R.layout.equity_card,parent, false)); // TODO
    }

    @Override
    public int getItemCount() {
        return myItems.size();
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {

      final EquityModel model = myItems.get(position);

        holder.scrip.setText(model.getTrading_symbol());
        holder.mis.setText("MIS Multiplier : "+model.getMis_multiplier()+"X");
        holder.cnc.setText("CNC Multiplier : 1X");
        holder.cal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                myListener.onItemClick(model);
            }
        });


    }

    public interface ItemListener {
        void onItemClick(EquityModel item);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        // TODO - Your view members

        TextView scrip,mis,cnc;
        Button cal;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            scrip = itemView.findViewById(R.id.scrip);
            mis=itemView.findViewById(R.id.mis_mul);
            cnc = itemView.findViewById(R.id.cnc_mul);
            cal=itemView.findViewById(R.id.cal);
        }
    }


}
                                