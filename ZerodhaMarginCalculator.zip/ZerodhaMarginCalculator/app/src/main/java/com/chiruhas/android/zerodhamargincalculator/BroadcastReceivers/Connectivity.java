package com.chiruhas.android.zerodhamargincalculator.BroadcastReceivers;

import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Toast;

import com.chiruhas.android.zerodhamargincalculator.R;

public class Connectivity extends BroadcastReceiver {
    ConnectivityManager connectivityManager;
    NetworkInfo networkInfo;
    AlertDialog.Builder alertDialog;
    AlertDialog dialog;
    @Override
    public void onReceive(Context context, Intent intent) {

        connectivityManager = (ConnectivityManager)context.getSystemService(context.CONNECTIVITY_SERVICE);
        if(connectivityManager!=null)
        {
            networkInfo = connectivityManager.getActiveNetworkInfo();

            if(networkInfo!=null && networkInfo.isConnected()){
                // dismiss
                if(dialog!=null)
                {
                    dialog.dismiss();
                    Toast.makeText(context, "Connected", Toast.LENGTH_SHORT).show();
                }

            }
            else
            {
                View view = LayoutInflater.from(context).inflate(R.layout.noconnection,null);
                alertDialog = new AlertDialog.Builder(context);
                alertDialog.setView(view);

                dialog = alertDialog.create();
                dialog.show();
                //show dialog
                Toast.makeText(context, "Disconnected", Toast.LENGTH_SHORT).show();
            }

        }
    }
}
